# Reservation API

Reservation API is a simple Rails application that allows an agent to manage service reservations for St Charles Automotive. The API enables agents to capture customer information, vehicle information, and secure a time slot for service appointments.

## Getting Started

1. Clone the repo, `cd` into the directory and run `bundle install`.
2. Once all the dependencies are installed, run `rails s` to start the server. This will also tell you where the api url is available, such as "http://127.0.0.1:3000/"
3. run `rails db:create` and `rails db:migrate` to set up the database

## API Endpoints
Note that you must create a Customer and a Vehicle before making a Reservation

The following endpoints are available in the Customer API:

- `GET /customers`: Retrieve all customers
- `POST /customers`: Create a new customer
Example Params:
{
  "customer": {
    "name": "Joseph Ogunbodede",
    "phone_number": "3018019677",
    "email": "josephogunbodede@gmail.com"
  }
}

The following endpoints are available in the Vehicle API:

- `GET /vehicles`: Retrieve all vehicles
- `POST /vehicles`: Create a new vehicle
Example Params:
{
  "vehicle": {
    "make": "Honda",
    "model": "Accord",
    "year": 2019,
    "license_plate": "BG4RTP2"
  }
}

The following endpoints are available in the Reservation API:

- `GET /reservations`: Retrieve all reservations
- `GET /reservations/:id`: Retrieve a specific reservation
- `POST /reservations`: Create a new reservation
    Example Param:
    {
        "reservation": {
            "start_time": "2024-03-07 10:00:00",
            "end_time": "2024-03-07 12:00:00",
            "customer_id": 1,
            "vehicle_id": 1
        }
    }
- `PUT /reservations/:id`: Update an existing reservation
- `DELETE /reservations/:id`: Delete a reservation

You may use a tool such as postman to test these API endpoints. Keep in mind you must make a customer and a vehicle first in order to create a reservation

## Testing

To run the test suite for the app suite, run the following command from the root of the project: `bundle exec rspec`