Rails.application.routes.draw do
  resources :customers, only: [:create, :index]
  resources :vehicles, only: [:create, :index]
  resources :reservations
end
