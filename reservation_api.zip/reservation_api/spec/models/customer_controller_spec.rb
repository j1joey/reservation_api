# frozen_string_literal: true

require 'rails_helper'

RSpec.describe CustomersController, type: :controller do
  describe 'POST #create' do
    context 'with valid attributes' do
      it 'creates a new customer' do
        expect do
          post :create, params: { customer: {
            name: 'John Doe',
            phone_number: '1234567890',
            email: 'john@example.com'
          } }
        end.to change(Customer, :count).by(1)
      end

      it 'returns a 200 created status' do
        post :create, params: { customer: {
          name: 'John Doe',
          phone_number: '1234567890',
          email: 'john@example.com'
        } }
        expect(response).to have_http_status(200)
      end
    end

    context 'with invalid attributes' do
      it 'does not create a new customer' do
        expect do
          post :create, params: { customer: {
            phone_number: '1234567890',
            email: 'john@example.com'
          } }
        end.to_not change(Customer, :count)
      end

      it 'returns an unprocessable entity status' do
        post :create, params: { customer: {
          phone_number: '1234567890',
          email: 'john@example.com'
        } }
        expect(response).to have_http_status(:unprocessable_entity)
      end
    end
  end
end
