# frozen_string_literal: true

require 'rails_helper'

RSpec.describe ReservationsController, type: :controller do
  let(:reservation) do
    Reservation.create(start_time: Time.now, end_time: Time.now + 6.hours, customer:, vehicle:)
  end
  let(:customer) { Customer.create(name: 'John Doe', phone_number: '1234567890', email: 'john@example.com') }
  let(:vehicle) { Vehicle.create(make: 'Toyota', model: 'Camry', year: 2022, license_plate: 'ABC123') }

  describe 'POST #create' do
    context 'with valid attributes' do
      it 'creates a new reservation' do
        expect do
          post :create,
               params: { reservation: { start_time: Time.now, end_time: Time.now + 6.hour, customer_id: customer.id,
                                        vehicle_id: vehicle.id } }
        end.to change(Reservation, :count).by(1)
      end

      it 'returns a 200 created status' do
        post :create,
             params: { reservation: { start_time: Time.now, end_time: Time.now + 6.hour, customer_id: customer.id,
                                      vehicle_id: vehicle.id } }
        expect(response).to have_http_status(200)
      end
    end

    context 'with invalid attributes' do
      it 'does not create a new reservation' do
        expect do
          post :create,
               params: { reservation: { start_time: nil, customer_id: customer.id, vehicle_id: vehicle.id } }
        end.to_not change(Reservation, :count)
      end

      it 'returns an unprocessable entity status' do
        post :create,
             params: { reservation: { start_time: nil, customer_id: customer.id, vehicle_id: vehicle.id } }
        expect(response).to have_http_status(:unprocessable_entity)
      end
    end

    context 'with overlapping reservation' do
      it 'returns an error' do
        post :create,
             params: { reservation: { start_time: reservation.start_time - 1.hour, end_time: reservation.end_time + 1.hour,
                                      customer_id: customer.id, vehicle_id: vehicle.id } }
        expect(response).to have_http_status(:unprocessable_entity)
        expect(JSON.parse(response.body)['error']).to eq('Time slot is already reserved')
      end
    end

    context 'with start time greater than end time' do
      it 'returns an error' do
        post :create,
             params: { reservation: { start_time: reservation.start_time + 1.hour, end_time: reservation.start_time,
                                      customer_id: customer.id, vehicle_id: vehicle.id } }
        expect(response).to have_http_status(:unprocessable_entity)
        expect(JSON.parse(response.body)['error']).to eq('Start time must be before end time')
      end
    end
  end

  describe 'PUT #update' do
    let!(:reservation) do
      Reservation.create(
        start_time: Time.new(2024, 3, 7, 12, 0, 0, '+00:00'),
        end_time: Time.new(2024, 3, 7, 18, 0, 0, '+00:00'),
        customer: Customer.create(name: 'John Doe', phone_number: '1234567890', email: 'john@example.com'),
        vehicle: Vehicle.create(make: 'Toyota', model: 'Camry', year: 2022, license_plate: 'ABC123')
      )
    end
    context 'with valid attributes' do
      it 'updates the requested reservation' do
        put :update,
            params: { id: reservation.id, reservation: { end_time: Time.new(2024, 3, 8, 12, 0, 0, '+00:00') } }
        reservation.reload
        expect(reservation.end_time).to eq(Time.new(2024, 3, 8, 12, 0, 0, '+00:00'))
      end

      it 'returns a success response' do
        put :update, params: { id: reservation.id, reservation: { end_time: Time.now + 6.hour } }
        expect(response).to have_http_status(200)
      end
    end

    context 'with invalid attributes' do
      it 'returns an unprocessable entity status' do
        patch :update, params: { id: reservation.id, reservation: { start_time: nil } }
        expect(response).to have_http_status(:unprocessable_entity)
      end
    end

    context 'with overlapping reservation' do
      let(:existing_reservation) do
        Reservation.create(start_time: Time.now - 1.hour, end_time: Time.now + 1.hour, customer:, vehicle:)
      end

      it 'returns an error' do
        put :update,
            params: { id: reservation.id,
                      reservation: { start_time: existing_reservation.start_time, end_time: existing_reservation.end_time,
                                     customer_id: reservation.customer_id, vehicle_id: reservation.vehicle_id } }
        expect(response).to have_http_status(:unprocessable_entity)
        expect(JSON.parse(response.body)['error']).to eq('Time slot is already reserved')
      end
    end
  end

  describe 'DELETE #destroy' do
    let!(:reservation) do
      Reservation.create(start_time: Time.now, end_time: Time.now + 6.hour,
                         customer: Customer.create(name: 'John Doe', phone_number: '1234567890', email: 'john@example.com'), vehicle: Vehicle.create(make: 'Toyota', model: 'Camry', year: 2022, license_plate: 'ABC123'))
    end
    it 'deletes specified reservation' do
      expect do
        delete :destroy, params: { id: reservation.id }
      end.to change(Reservation, :count).by(-1)
    end
  end
end
