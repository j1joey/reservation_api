# frozen_string_literal: true

class CustomersController < ApplicationController
  def create
    @customer = Customer.new(customer_params)
    if @customer.save
      render json: @customer, status: 200
    else
      render json: { error: 'Error creating customer' }, status: :unprocessable_entity
    end
  end

  # GET /customers
  def index
    @customer = Customer.all
    render json: @customer
  end

  private

  def customer_params
    params.require(:customer).permit(:name, :phone_number, :email)
  end
end
