# frozen_string_literal: true

class ReservationsController < ApplicationController
  before_action :set_reservation, only: %i[show update destroy]

  # GET /reservations
  def index
    @reservations = Reservation.all
    render json: @reservations
  end

  # GET /reservations/id
  def show
    render json: @reservation
  end

  # POST /reservations
  def create
    @reservation = Reservation.new(reservation_params)

    if overlapping_reservation?
      render json: { error: 'Time slot is already reserved' }, status: :unprocessable_entity
    elsif @reservation.start_time && @reservation.end_time && @reservation.start_time >= @reservation.end_time
      render json: { error: 'Start time must be before end time' }, status: :unprocessable_entity
    elsif @reservation.save
      render json: @reservation, status: 200
    else
      render json: { error: 'Error creating reservation' }, status: :unprocessable_entity
    end
  end

  # PATCH/PUT /reservations/id
  def update
    if reservation_params_valid?
      if overlapping_reservation_for_update?
        render json: { error: 'Time slot is already reserved' }, status: :unprocessable_entity
      elsif @reservation.update(reservation_params)
        render json: @reservation, status: 200
      else
        render json: { error: 'Error updating reservation' }, status: :unprocessable_entity
      end
    else
      render json: { error: 'Error updating reservation due to params' }, status: :unprocessable_entity
    end
  end

  # DELETE /reservations/id
  def destroy
    @reservation.destroy
    render json: { message: 'Reservation deleted successfully' }
  end

  private

  def set_reservation
    @reservation = Reservation.find_by(id: params[:id])
    return if @reservation

    render json: { error: 'Error finding reservation' }, status: :unprocessable_entity
  end

  def reservation_params
    params.require(:reservation).permit(:start_time, :end_time, :customer_id, :vehicle_id)
  end

  def overlapping_reservation?
    Reservation.where('start_time < ? AND end_time > ?', @reservation.end_time, @reservation.start_time)
               .exists?
  end

  def overlapping_reservation_for_update?
    Reservation.where.not(id: @reservation.id)
               .where('start_time < ? AND end_time > ?', params[:reservation][:end_time], params[:reservation][:start_time])
               .exists?
  end

  def reservation_params_valid?
    @reservation.assign_attributes(reservation_params)
    @reservation.valid?
  end
end
