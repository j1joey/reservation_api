# frozen_string_literal: true

class VehiclesController < ApplicationController
  def create
    @vehicle = Vehicle.new(vehicle_params)
    if @vehicle.save
      render json: @vehicle, status: 200
    else
      render json: { error: 'Error saving vehicle' }, status: :unprocessable_entity
    end
  end

  # GET /vehicles
  def index
    @vehicles = Vehicle.all
    render json: @vehicles
  end

  private

  def vehicle_params
    params.require(:vehicle).permit(:make, :model, :year, :license_plate)
  end
end
