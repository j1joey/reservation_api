# frozen_string_literal: true

class Reservation < ApplicationRecord
  belongs_to :customer
  belongs_to :vehicle
  validates :start_time, :end_time, :customer_id, :vehicle_id, presence: true
end
