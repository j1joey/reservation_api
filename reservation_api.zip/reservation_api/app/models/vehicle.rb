# frozen_string_literal: true

class Vehicle < ApplicationRecord
  validates :make, :model, :year, :license_plate, presence: true
end
